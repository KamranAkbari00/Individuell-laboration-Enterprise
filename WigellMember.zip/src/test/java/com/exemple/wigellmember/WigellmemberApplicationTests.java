package com.exemple.wigellmember;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WigellmemberApplicationTests {

	@Test
	void contextLoads() {
	}

}
